package com.lm.interview;

/**
 * Hello world!
 *
 */
public class App {
	ClassLoader classLoader = getClass().getClassLoader();

	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
			Util.getFromFile(args[i]);
		}

	}

}
