package com.lm.interview;

import org.junit.Test;

public class ShoppingCartFromFilesTest {

	@Test
	public void testFileEntry1() {
		Util.getFromFile("source/in1.txt");
	}

	@Test
	public void testFileEntry2() {
		Util.getFromFile("source/in2.txt");
	}

	@Test
	public void testFileEntry3() {
		Util.getFromFile("source/in3.txt");
	}

}
